# lang: Python, file: proxy.py, target: mitmproxy 10+, Windows/Linux
# Free Fire MITM proxy — intercepts asset CDN, serves patched files per port
# run via: run.bat (Windows) or mitmdump -s proxy.py --listen-port 7771

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from urllib.parse import unquote

from mitmproxy import ctx, http

# ─── PATHS ────────────────────────────────────────────────────────────────────
ROOT        = Path(__file__).resolve().parent
PATCHES_DIR = ROOT / "game_patches"
ALLOWLIST   = ROOT / "allowed_ips.json"

# ─── PORT → PATCH FOLDER MAP ──────────────────────────────────────────────────
PORT_CONFIG: dict[int, dict] = {
    7771: {"name": "Aim Drag",     "folder": "Aim Drag 7771"},
    7772: {"name": "Aim Neck",     "folder": "Aim Neck 7772"},
    7773: {"name": "Aim Body",     "folder": "Aim Body 7773"},
    7774: {"name": "Aim Drag Top", "folder": "Aim Drag Top 7774"},
}

# ─── TELEMETRY BLOCKLIST ──────────────────────────────────────────────────────
BLOCKED: list[str] = [
    "report.garena",
    "report.tencent",
    "firebase",
    "firebaselogging",
    "firebasecrash",
    "firebaseremoteconfig",
    "ffvoice",
    "ffvoice_uploadlog",
    "datadome",
    "datadome.co",
]

# ─── ALLOWLIST ────────────────────────────────────────────────────────────────
def _load_allowlist() -> dict:
    try:
        if ALLOWLIST.exists():
            return json.loads(ALLOWLIST.read_text())
    except Exception:
        pass
    return {}

def is_ip_allowed(ip: str) -> bool:
    """
    True if ip is in allowed_ips.json and not expired.
    Set expires_at=9999999999 for permanent.
    Delete the file to run open (all IPs pass).
    """
    data = _load_allowlist()
    if not data:
        return True
    entry = data.get(ip)
    if entry is None:
        return False
    return time.time() < entry.get("expires_at", 0)

# ─── HELPERS ──────────────────────────────────────────────────────────────────
def _port() -> int:
    try:
        return ctx.options.listen_port
    except Exception:
        return int(os.environ.get("PROXY_PORT", "7771"))

def _patch_dir() -> Path:
    cfg = PORT_CONFIG.get(_port(), PORT_CONFIG[7771])
    return PATCHES_DIR / cfg["folder"]

def _read(filename: str) -> bytes:
    path = _patch_dir() / filename
    if not path.exists():
        raise FileNotFoundError(path)
    return path.read_bytes()

def _is_blocked(flow: http.HTTPFlow) -> bool:
    try:
        host = flow.request.pretty_host.lower()
        url  = flow.request.pretty_url.lower()
    except Exception:
        return False
    for pat in BLOCKED:
        p = pat.lower()
        if p in host or p in url:
            return True
    return False

def _serve(flow: http.HTTPFlow, filename: str, ctype: str) -> None:
    try:
        data = _read(filename)
    except FileNotFoundError:
        flow.response = http.Response.make(
            404, b"Not Found", {"Content-Type": "text/plain"}
        )
        ctx.log.warn(f"[FF-PROXY] missing: {filename} in {_patch_dir()}")
        return

    size   = len(data)
    method = flow.request.method.upper()
    rng    = flow.request.headers.get("Range", "")

    hdrs: dict[str, str] = {
        "Server":                      "GSE",
        "Content-Type":                ctype,
        "Content-Length":              str(size),
        "Cache-Control":               "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma":                      "no-cache",
        "Expires":                     "0",
        "Accept-Ranges":               "bytes",
        "Access-Control-Allow-Origin": "*",
        "Connection":                  "close",
    }

    if rng.lower().startswith("bytes=") and "," not in rng:
        try:
            left, right = rng[6:].split("-", 1)
            start = int(left) if left else 0
            end   = min(int(right) if right else size - 1, size - 1)
            if 0 <= start <= end:
                chunk = data[start:end + 1]
                hdrs["Content-Range"]  = f"bytes {start}-{end}/{size}"
                hdrs["Content-Length"] = str(len(chunk))
                flow.response = http.Response.make(
                    206, b"" if method == "HEAD" else chunk, hdrs
                )
                return
        except Exception:
            pass

    flow.response = http.Response.make(
        200, b"" if method == "HEAD" else data, hdrs
    )
    ctx.log.info(f"[FF-PROXY] served {filename} ({size}B)")

# ─── INTERCEPT RULES ──────────────────────────────────────────────────────────
def _intercept_7773(flow: http.HTTPFlow, path: str, url: str) -> bool:
    if "core-gmc.freefiremobile.com/live/abhotupdates/ios/1.126.16/fileinfo" in url:
        _serve(flow, "fileinfo", "text/plain; charset=utf-8")
    elif "cache_res" in path or "gameassetbundles/cache_res" in url:
        _serve(flow, "cache_res", "application/octet-stream")
    elif "config/splitedresconfs/partialresconf" in path:
        _serve(flow, "partialresconf", "application/octet-stream")
    elif "versioninfo" in path:
        _serve(flow, "versioninfo", "text/plain; charset=utf-8")
    elif "assetindexer" in path or "gameassetbundles/avatar/assetindexer" in url:
        _serve(flow, "assetindexer.gz", "application/gzip")
    else:
        return False
    return True

def _intercept_default(flow: http.HTTPFlow, path: str, url: str) -> bool:
    if "fileinfo" in path:
        _serve(flow, "fileinfo", "text/plain; charset=utf-8")
    elif "versioninfo" in path:
        _serve(flow, "versioninfo", "text/plain; charset=utf-8")
    elif "assetindexer" in path or "gameassetbundles/avatar/assetindexer" in url:
        _serve(flow, "assetindexer.gz", "application/gzip")
    else:
        return False
    return True

# ─── MITMPROXY HOOK ───────────────────────────────────────────────────────────
def request(flow: http.HTTPFlow) -> None:
    client_ip = flow.client_conn.address[0]

    if not is_ip_allowed(client_ip):
        ctx.log.warn(f"[FF-PROXY] blocked: {client_ip}")
        flow.response = http.Response.make(
            403, b"Unauthorized: IP not in allowlist.",
            {"Content-Type": "text/plain"}
        )
        return

    if _is_blocked(flow):
        ctx.log.info(f"[FF-PROXY] dropped telemetry: {flow.request.pretty_host}")
        flow.response = http.Response.make(204, b"", {"Content-Type": "text/plain"})
        return

    path = unquote(flow.request.path.split("?", 1)[0]).lower()
    url  = unquote(flow.request.pretty_url).lower()
    port = _port()

    hit = _intercept_7773(flow, path, url) if port == 7773 \
          else _intercept_default(flow, path, url)

    if hit:
        name = PORT_CONFIG.get(port, {}).get("name", str(port))
        ctx.log.info(f"[FF-PROXY:{port}/{name}] intercepted → {path}")
