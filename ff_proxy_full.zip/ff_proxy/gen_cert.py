# lang: Python, file: gen_cert.py, target: Windows/Linux, Python 3.8+
# Generates a self-signed mitmproxy CA cert + key without needing OpenSSL binary.
# Outputs: certs/mitmproxy-ca.pem  (cert+key bundle for mitmproxy --set confdir)
#          certs/mitmproxy-ca-cert.cer  (DER, install on Android/iOS)
#          certs/mitmproxy-ca-cert.pem  (PEM, install on Linux/Windows)
#
# deps: pip install cryptography
#
# mitmproxy also auto-generates its own CA on first run (~/.mitmproxy/).
# Use THIS script only if you want a custom CA stored inside the project folder
# so every machine running the proxy shares the same trusted cert.

from __future__ import annotations

import datetime
import ipaddress
from pathlib import Path

try:
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
except ImportError:
    raise SystemExit(
        "[!] Missing dep: pip install cryptography"
    )

CERTS_DIR = Path(__file__).resolve().parent / "certs"
CERTS_DIR.mkdir(exist_ok=True)

CA_SUBJECT = {
    NameOID.COUNTRY_NAME:             "US",
    NameOID.ORGANIZATION_NAME:        "FF-Proxy CA",
    NameOID.COMMON_NAME:              "FF-Proxy Root CA",
    NameOID.ORGANIZATIONAL_UNIT_NAME: "FF-Proxy",
}

KEY_BITS   = 2048
VALID_DAYS = 3650   # 10 years


def build_ca() -> tuple:
    """Generate RSA key + self-signed CA certificate."""
    key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=KEY_BITS,
    )

    subject = issuer = x509.Name([
        x509.NameAttribute(oid, val) for oid, val in CA_SUBJECT.items()
    ])

    now = datetime.datetime.utcnow()
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=VALID_DAYS))
        .add_extension(
            x509.BasicConstraints(ca=True, path_length=None),
            critical=True,
        )
        .add_extension(
            x509.SubjectKeyIdentifier.from_public_key(key.public_key()),
            critical=False,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                key_cert_sign=True,
                crl_sign=True,
                content_commitment=False,
                key_encipherment=False,
                data_encipherment=False,
                key_agreement=False,
                encipher_only=False,
                decipher_only=False,
            ),
            critical=True,
        )
        .sign(key, hashes.SHA256())
    )
    return key, cert


def write_outputs(key, cert) -> None:
    key_pem  = key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.TraditionalOpenSSL,
        serialization.NoEncryption(),
    )
    cert_pem = cert.public_bytes(serialization.Encoding.PEM)
    cert_der = cert.public_bytes(serialization.Encoding.DER)

    # mitmproxy expects key+cert concatenated in one PEM for --set confdir usage
    bundle = CERTS_DIR / "mitmproxy-ca.pem"
    bundle.write_bytes(key_pem + cert_pem)
    print(f"[+] CA bundle (key+cert):  {bundle}")

    # PEM cert only — install on Windows / Linux trust stores
    pem_out = CERTS_DIR / "mitmproxy-ca-cert.pem"
    pem_out.write_bytes(cert_pem)
    print(f"[+] PEM cert:              {pem_out}")

    # DER cert — install on Android (Settings > Security > Install certificate)
    #            and iOS (Settings > General > VPN & Device Management)
    cer_out = CERTS_DIR / "mitmproxy-ca-cert.cer"
    cer_out.write_bytes(cert_der)
    print(f"[+] DER cert (.cer):       {cer_out}")


def main() -> None:
    print("[*] Generating FF-Proxy CA certificate ...")
    key, cert = build_ca()
    write_outputs(key, cert)
    print("\n[*] Install guide:")
    print("    Android : push .cer to phone → Settings > Security > Install certificate")
    print("    iOS     : AirDrop .cer → Settings > General > VPN & Device Management → trust it")
    print("    Windows : double-click .cer → Install → Trusted Root CAs → Local Machine")
    print("    Linux   : sudo cp certs/mitmproxy-ca-cert.pem /usr/local/share/ca-certificates/ff-proxy.crt")
    print("              sudo update-ca-certificates")
    print()
    print("[*] Point mitmproxy at the custom CA:")
    print(f"    mitmdump -s proxy.py --set confdir={CERTS_DIR} --listen-port 7771")
    print()
    print("[OK] Done.")


if __name__ == "__main__":
    main()
