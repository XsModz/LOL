# lang: Python, file: proxy_config.py, target: imported by proxy.py
# port → folder + patch manifest

import os

PORT_CONFIG: dict[int, dict] = {
    7771: {
        "name":        "Aim Drag",
        "folder":      "Aim Drag 7771",
        "description": "Standard aim drag patches",
        "patches":     ["fileinfo", "versioninfo", "assetindexer"],
    },
    7772: {
        "name":        "Aim Neck",
        "folder":      "Aim Neck 7772",
        "description": "Neck-target aim patches",
        "patches":     ["fileinfo", "versioninfo", "assetindexer"],
    },
    7773: {
        "name":        "Aim Body",
        "folder":      "Aim Body 7773",
        "description": "Body aim + cache_res / partialresconf",
        "patches":     ["fileinfo", "versioninfo", "assetindexer", "cache_res", "partialresconf"],
    },
    7774: {
        "name":        "Aim Drag Top",
        "folder":      "Aim Drag Top 7774",
        "description": "High-priority drag patches",
        "patches":     ["fileinfo", "versioninfo", "assetindexer"],
    },
}

CURRENT_PORT: int = int(os.environ.get("PROXY_PORT", "7771"))

def get_port_config(port: int | None = None) -> dict:
    return PORT_CONFIG.get(port or CURRENT_PORT, PORT_CONFIG[7771])

def get_all_ports() -> list[int]:
    return sorted(PORT_CONFIG.keys())

def get_patch_folder(port: int | None = None) -> str:
    return get_port_config(port).get("folder", "")
