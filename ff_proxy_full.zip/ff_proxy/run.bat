@echo off
setlocal EnableDelayedExpansion
title FF-Proxy Launcher

:: ─── PATHS ────────────────────────────────────────────────────────────────────
set "ROOT=%~dp0"
set "CERT_DIR=%ROOT%certs"
set "CERT_BUNDLE=%CERT_DIR%\mitmproxy-ca.pem"
set "PROXY_SCRIPT=%ROOT%proxy.py"
set "CERT_SCRIPT=%ROOT%gen_cert.py"

:: ─── CHECK PYTHON ─────────────────────────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo [!] Python not found. Install from https://python.org and add to PATH.
    pause & exit /b 1
)

:: ─── CHECK MITMPROXY ──────────────────────────────────────────────────────────
mitmdump --version >nul 2>&1
if errorlevel 1 (
    echo [!] mitmproxy not found.
    echo [*] Installing ...
    python -m pip install mitmproxy cryptography --quiet
    if errorlevel 1 (
        echo [!] pip install failed. Run manually: pip install mitmproxy cryptography
        pause & exit /b 1
    )
    echo [+] Installed.
)

:: ─── CHECK CRYPTOGRAPHY (for gen_cert.py) ────────────────────────────────────
python -c "import cryptography" >nul 2>&1
if errorlevel 1 (
    echo [*] Installing cryptography ...
    python -m pip install cryptography --quiet
)

:MENU
cls
echo.
echo  ╔══════════════════════════════════════════╗
echo  ║          FF-PROXY LAUNCHER               ║
echo  ╠══════════════════════════════════════════╣
echo  ║  [1]  Generate / Regen CA Certificate   ║
echo  ║  [2]  Run  -  Aim Drag     (port 7771)  ║
echo  ║  [3]  Run  -  Aim Neck     (port 7772)  ║
echo  ║  [4]  Run  -  Aim Body     (port 7773)  ║
echo  ║  [5]  Run  -  Aim Drag Top (port 7774)  ║
echo  ║  [6]  Run ALL four ports (4 windows)    ║
echo  ║  [7]  Show CA install instructions      ║
echo  ║  [0]  Exit                              ║
echo  ╚══════════════════════════════════════════╝
echo.
set /p CHOICE="  Choose: "

if "%CHOICE%"=="1" goto GEN_CERT
if "%CHOICE%"=="2" goto RUN_7771
if "%CHOICE%"=="3" goto RUN_7772
if "%CHOICE%"=="4" goto RUN_7773
if "%CHOICE%"=="5" goto RUN_7774
if "%CHOICE%"=="6" goto RUN_ALL
if "%CHOICE%"=="7" goto SHOW_INSTALL
if "%CHOICE%"=="0" exit /b 0
goto MENU

:: ─── CERT GEN ─────────────────────────────────────────────────────────────────
:GEN_CERT
cls
echo [*] Generating CA certificate ...
python "%CERT_SCRIPT%"
if errorlevel 1 (
    echo [!] Certificate generation failed.
) else (
    echo.
    echo [+] Certificate files are in: %CERT_DIR%
)
echo.
pause
goto MENU

:: ─── SINGLE PORT LAUNCHERS ────────────────────────────────────────────────────
:RUN_7771
call :CHECK_CERT
cls
echo [*] Starting Aim Drag on port 7771 ...
call :LAUNCH 7771 "Aim Drag 7771"
goto MENU

:RUN_7772
call :CHECK_CERT
cls
echo [*] Starting Aim Neck on port 7772 ...
call :LAUNCH 7772 "Aim Neck 7772"
goto MENU

:RUN_7773
call :CHECK_CERT
cls
echo [*] Starting Aim Body on port 7773 ...
call :LAUNCH 7773 "Aim Body 7773"
goto MENU

:RUN_7774
call :CHECK_CERT
cls
echo [*] Starting Aim Drag Top on port 7774 ...
call :LAUNCH 7774 "Aim Drag Top 7774"
goto MENU

:: ─── RUN ALL FOUR ─────────────────────────────────────────────────────────────
:RUN_ALL
call :CHECK_CERT
cls
echo [*] Launching all four proxy instances ...
start "FF-Proxy Aim Drag     [7771]" cmd /k "set PROXY_PORT=7771 && mitmdump -s "%PROXY_SCRIPT%" --set confdir="%CERT_DIR%" --listen-host 0.0.0.0 --listen-port 7771"
timeout /t 1 /nobreak >nul
start "FF-Proxy Aim Neck     [7772]" cmd /k "set PROXY_PORT=7772 && mitmdump -s "%PROXY_SCRIPT%" --set confdir="%CERT_DIR%" --listen-host 0.0.0.0 --listen-port 7772"
timeout /t 1 /nobreak >nul
start "FF-Proxy Aim Body     [7773]" cmd /k "set PROXY_PORT=7773 && mitmdump -s "%PROXY_SCRIPT%" --set confdir="%CERT_DIR%" --listen-host 0.0.0.0 --listen-port 7773"
timeout /t 1 /nobreak >nul
start "FF-Proxy Aim Drag Top [7774]" cmd /k "set PROXY_PORT=7774 && mitmdump -s "%PROXY_SCRIPT%" --set confdir="%CERT_DIR%" --listen-host 0.0.0.0 --listen-port 7774"
echo [+] Four windows launched. Close them individually to stop.
echo.
pause
goto MENU

:: ─── INSTALL INSTRUCTIONS ─────────────────────────────────────────────────────
:SHOW_INSTALL
cls
echo.
echo  ─── CA CERTIFICATE INSTALL ──────────────────────────────────────────
echo.
echo  File to install:
echo    %CERT_DIR%\mitmproxy-ca-cert.cer   (Android / iOS / Windows)
echo    %CERT_DIR%\mitmproxy-ca-cert.pem   (Linux)
echo.
echo  Android:
echo    1. Copy mitmproxy-ca-cert.cer to phone (USB / ADB / share)
echo    2. Settings ^> Security ^> Install certificate ^> CA certificate
echo    3. Select the .cer file
echo.
echo  iOS:
echo    1. AirDrop or email the .cer to device
echo    2. Settings ^> General ^> VPN ^& Device Management ^> tap profile ^> Install
echo    3. Settings ^> General ^> About ^> Certificate Trust Settings ^> enable it
echo.
echo  Windows (trust store):
echo    1. Double-click mitmproxy-ca-cert.cer
echo    2. Install Certificate ^> Local Machine ^> Trusted Root CAs ^> Finish
echo.
echo  Linux:
echo    sudo cp "%CERT_DIR%\mitmproxy-ca-cert.pem" /usr/local/share/ca-certificates/ff-proxy.crt
echo    sudo update-ca-certificates
echo.
echo  ─── DEVICE PROXY SETTINGS ───────────────────────────────────────────
echo.
echo    Host : [your PC IP on LAN]
echo    Port : 7771 / 7772 / 7773 / 7774  (pick the patch mode you want)
echo.
echo  ─────────────────────────────────────────────────────────────────────
echo.
pause
goto MENU

:: ─── HELPERS ──────────────────────────────────────────────────────────────────
:CHECK_CERT
:: Warn if cert bundle missing, offer to generate
if not exist "%CERT_BUNDLE%" (
    echo.
    echo  [!] CA certificate not found: %CERT_BUNDLE%
    echo  [*] Run option [1] first to generate it, or mitmproxy will use its default CA.
    echo      Default CA lives in %%USERPROFILE%%\.mitmproxy\ — install that cert instead.
    echo.
    pause
)
goto :EOF

:LAUNCH
:: %1 = port number, %2 = window title string
set "_PORT=%~1"
set "_TITLE=%~2"
if exist "%CERT_BUNDLE%" (
    start "%_TITLE% [%_PORT%]" cmd /k "set PROXY_PORT=%_PORT% && mitmdump -s "%PROXY_SCRIPT%" --set confdir="%CERT_DIR%" --listen-host 0.0.0.0 --listen-port %_PORT%"
) else (
    start "%_TITLE% [%_PORT%]" cmd /k "set PROXY_PORT=%_PORT% && mitmdump -s "%PROXY_SCRIPT%" --listen-host 0.0.0.0 --listen-port %_PORT%"
)
goto :EOF
